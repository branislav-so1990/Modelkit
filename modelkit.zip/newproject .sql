-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Jul 23, 2019 at 03:28 AM
-- Server version: 5.7.23
-- PHP Version: 7.2.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `newproject`
--

-- --------------------------------------------------------

--
-- Table structure for table `galerije`
--

DROP TABLE IF EXISTS `galerije`;
CREATE TABLE IF NOT EXISTS `galerije` (
  `id` int(3) UNSIGNED NOT NULL AUTO_INCREMENT,
  `model_id` int(3) NOT NULL,
  `naziv_slike` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=73 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `galerije`
--

INSERT INTO `galerije` (`id`, `model_id`, `naziv_slike`) VALUES
(31, 47, 'spirfire.jpg'),
(32, 47, '109g6.jpg'),
(33, 47, 'f4fu corsair.jpg'),
(34, 51, 'zuikaku2.jpg'),
(35, 53, 'plastic-model-planes-1.jpg'),
(36, 54, 'plastic-model-planes-1.jpg'),
(37, 55, 'mustang2.jpg'),
(38, 57, 'bismarck1.jpg'),
(41, 60, 'f16second.jpg'),
(42, 61, 'corvette2.jpg'),
(65, 81, 'audi 2.jpg'),
(66, 81, 'audi3.jpg'),
(67, 81, 'audi4.jpg'),
(68, 82, '1.jpg'),
(69, 82, '2.jpg'),
(70, 82, '3.jpg'),
(71, 82, '4.jpg'),
(72, 82, '5.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `kategorije`
--

DROP TABLE IF EXISTS `kategorije`;
CREATE TABLE IF NOT EXISTS `kategorije` (
  `id` int(2) UNSIGNED NOT NULL AUTO_INCREMENT,
  `kategorija` varchar(30) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `kategorije`
--

INSERT INTO `kategorije` (`id`, `kategorija`) VALUES
(1, 'automobili'),
(2, 'avioni'),
(3, 'brodovi');

-- --------------------------------------------------------

--
-- Table structure for table `komentari`
--

DROP TABLE IF EXISTS `komentari`;
CREATE TABLE IF NOT EXISTS `komentari` (
  `komentar_id` int(3) NOT NULL AUTO_INCREMENT,
  `korisnik_id` int(3) NOT NULL,
  `model_id` int(3) NOT NULL,
  `komentar_sadrzaj` text NOT NULL,
  `komentar_vreme` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `komentar_obrisan` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`komentar_id`)
) ENGINE=MyISAM AUTO_INCREMENT=75 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `komentari`
--

INSERT INTO `komentari` (`komentar_id`, `korisnik_id`, `model_id`, `komentar_sadrzaj`, `komentar_vreme`, `komentar_obrisan`) VALUES
(64, 35, 61, 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. ', '2019-07-16 03:47:12', 0),
(74, 39, 82, 'The liner was equipped with the ultimate in elegance and luxury for service with the noted transatlantic White Star Line. ', '2019-07-23 02:28:39', 0),
(62, 37, 55, 'Odlican!', '2019-07-09 03:48:17', 0),
(61, 37, 57, 'Sjajno!', '2019-07-09 03:47:46', 0),
(60, 35, 57, 'Odličan model, preporuke!', '2019-07-09 03:46:39', 0),
(73, 34, 82, 'Easy to build due to torsional resistance of components; Detailed hull showing material structure; Three ship\'s screws', '2019-07-23 02:24:33', 0),
(58, 23, 53, 'Fantastic model, best one Ive had!', '2019-06-24 06:39:20', 0),
(57, 23, 49, 'Nije MkIX vec MkXVI :)', '2019-06-23 03:36:13', 0),
(56, 23, 48, 'jjjjj', '2019-06-20 09:30:46', 0),
(65, 37, 61, 'Nemo molestiae excepturi quae obcaecati, deserunt harum commodi corrupti tenetur asperiores! Alias, reprehenderit.', '2019-07-16 03:47:48', 0),
(66, 33, 49, 'Lorem Kiae excepturi quae obcaecati, deserunt harum commodi corrupti tenetur asperiores! Alias, reprehenderit.', '2019-07-16 03:58:40', 0),
(68, 34, 81, 'Sjajan model ! ', '2019-07-21 04:07:44', 0),
(69, 35, 62, 'Svidja mi se!', '2019-07-22 03:54:33', 0),
(70, 33, 54, 'Model nema na stanju', '2019-07-23 01:02:59', 0),
(72, 33, 81, 'alert()', '2019-07-23 01:39:19', 1),
(71, 33, 81, 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent non leo quam. Phasellus in vehicula tellus. Suspendisse eu dolor dui. Etiam euismod sit amet eros at tincidunt. Sed convallis pulvinar libero', '2019-07-23 01:14:45', 0);

-- --------------------------------------------------------

--
-- Table structure for table `korisnici`
--

DROP TABLE IF EXISTS `korisnici`;
CREATE TABLE IF NOT EXISTS `korisnici` (
  `id` int(4) UNSIGNED NOT NULL AUTO_INCREMENT,
  `korisnik_ime` varchar(30) NOT NULL,
  `korisnik_prezime` varchar(30) NOT NULL,
  `korisnik_lozinka` varchar(256) NOT NULL,
  `korisnik_email` varchar(50) NOT NULL,
  `korisnik_status` enum('admin','korisnik') NOT NULL DEFAULT 'korisnik',
  `korisnik_izmenjen` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `korisnik_validan` int(15) NOT NULL,
  `korisnik_obrisan` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `korisnici`
--

INSERT INTO `korisnici` (`id`, `korisnik_ime`, `korisnik_prezime`, `korisnik_lozinka`, `korisnik_email`, `korisnik_status`, `korisnik_izmenjen`, `korisnik_validan`, `korisnik_obrisan`) VALUES
(33, 'Branislav', 'Bačić', '$2y$10$UumKKJZShybg0sG0wy7ckOfTrQjMPdJqAmNKgp.RcSLucH1R.WqLS', 'bane@gmail.com', 'admin', '2019-07-23 01:10:21', 1, 0),
(34, 'Boško', 'Bogojević', '$2y$10$eTR4.FtCrrX5TO.LMIR1X.8qPKen80pzgjCSgnlq1knwTY9qHLM2m', 'bbosko@gmail.com', 'admin', '2019-07-22 03:41:03', 1, 0),
(35, 'Nikola', 'Nikolić', '$2y$10$4AtGsonEIInlgO6O5By54e71AW41qTcEp2yynvJli6ARolEimAopu', 'nikola@hotmail.com', 'korisnik', '2019-07-08 03:50:35', 1, 0),
(36, 'Marko', 'Marković', '$2y$10$9cFyBMvI3002H.QchQoGEugon/XLAANGv5hNrOxvvK7pHMd4m4s2K', 'mare@gmail.com', 'korisnik', '2019-07-08 04:03:14', 1562558594, 0),
(37, 'Joca', 'Karburator', '$2y$10$P42qy0pobsehxCvd9tBUhOZO46bgc3t7E4l57Rl2JDBkJcXoRdxzu', 'joca@gmail.com', 'korisnik', '2019-07-08 04:03:58', 1, 0),
(38, 'Jovan', 'Jovanović', '$2y$10$dCa3U2ujzruJHKFuIfLcQOwcsxB2BqBlW5NpTiivJGB1DnVHTyfgC', 'jovan@gmail.rs', 'korisnik', '2019-07-23 02:37:53', 1563767027, 0),
(39, 'Petar', 'Petrovic', '$2y$10$ImIul9jEkUbEXuZMXhp.reNMdbIXQIkrC2idSxtGJSaPUw5o9uzIO', 'pera@gmail.rs', 'korisnik', '2019-07-23 02:35:13', 1563848015, 0);

-- --------------------------------------------------------

--
-- Table structure for table `korpa`
--

DROP TABLE IF EXISTS `korpa`;
CREATE TABLE IF NOT EXISTS `korpa` (
  `id` int(3) UNSIGNED NOT NULL AUTO_INCREMENT,
  `id_kupca` int(3) NOT NULL,
  `id_proizvoda` int(3) NOT NULL,
  `vreme` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `vreme_kupovine` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `kupljen` int(1) NOT NULL DEFAULT '0',
  `adresa` varchar(30) DEFAULT NULL,
  `telefon` varchar(15) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=85 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `korpa`
--

INSERT INTO `korpa` (`id`, `id_kupca`, `id_proizvoda`, `vreme`, `vreme_kupovine`, `kupljen`, `adresa`, `telefon`) VALUES
(83, 35, 57, '2019-07-09 03:46:23', NULL, 0, NULL, NULL),
(81, 23, 48, '2019-07-08 02:19:45', NULL, 0, NULL, NULL),
(82, 33, 55, '2019-07-09 03:43:05', '2019-07-09 03:43:25', 1, 'neka adresa', '111222333');

-- --------------------------------------------------------

--
-- Table structure for table `modeli`
--

DROP TABLE IF EXISTS `modeli`;
CREATE TABLE IF NOT EXISTS `modeli` (
  `id` int(4) NOT NULL AUTO_INCREMENT,
  `model_kategorija` int(1) NOT NULL,
  `model_naziv` varchar(30) NOT NULL,
  `model_opis` text,
  `model_cena` int(5) NOT NULL,
  `model_slika` varchar(100) NOT NULL,
  `model_lajk` int(4) NOT NULL DEFAULT '0',
  `model_dislajk` int(4) NOT NULL DEFAULT '0',
  `model_pregledi` int(3) NOT NULL DEFAULT '0',
  `model_dostupan` int(1) DEFAULT '1',
  `model_vreme` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `model_izmenjen` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `model_obrisan` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=83 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `modeli`
--

INSERT INTO `modeli` (`id`, `model_kategorija`, `model_naziv`, `model_opis`, `model_cena`, `model_slika`, `model_lajk`, `model_dislajk`, `model_pregledi`, `model_dostupan`, `model_vreme`, `model_izmenjen`, `model_obrisan`) VALUES
(48, 1, 'Dodge Vajper', 'Lorem Ipsum excepturi quae obcaecati, deserunt harum commodi corrupti tenetur asperiores! Alias, reprehenderit.', 100, 'dodge-viper.jpg', 0, 0, 48, 1, '2019-06-20 05:07:26', '2019-07-23 01:26:45', 0),
(49, 2, 'Supermarine Spitfire', 'Lorem Ipsum excepturi quae obcaecati, deserunt harum commodi corrupti tenetur asperiores! Alias, reprehenderit.', 2450, 'spirfire.jpg', 0, 0, 20, 1, '2019-06-23 03:34:08', '2019-07-16 03:58:56', 0),
(50, 1, 'Aston Martin ', 'Aston Martin LaMans winner', 2399, 'car-model-kit-6.jpg', 0, 0, 3, 1, '2019-06-24 01:02:51', '2019-07-16 03:41:36', 0),
(54, 2, 'A7D Corsair II', 'USAF Corsair plastic model 1:32 scale', 2980, 'a7d_corsair.jpg', 0, 0, 59, 0, '2019-06-24 06:42:09', '2019-07-23 01:45:43', 0),
(55, 1, 'Shelby Mustang', 'Shelby Mustang GT-350H 1:24 scale plastic model', 2099, 'mustang.jpeg', 0, 0, 8, 1, '2019-07-09 03:31:55', '2019-07-15 02:00:08', 0),
(56, 3, 'Forestal aircraft carrier', 'Forestal class USN aircraft carrier 1:542scale', 3200, 'forestal.jpg', 0, 0, 3, 0, '2019-07-09 03:37:26', '2019-07-10 03:48:34', 0),
(57, 3, 'Bismarck', 'German battleship Bismarck plastic model', 4100, 'bismarck.jpeg', 0, 0, 7, 1, '2019-07-09 03:41:54', '2019-07-09 03:51:10', 0),
(60, 2, 'F-16 Falcon', 'Fighting Falcon Locheed MLU 1:72 scale', 3600, 'f16main.jpg', 0, 0, 1, 1, '2019-07-15 03:27:06', '2019-07-23 02:15:53', 0),
(61, 1, 'Corvette', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Laudantium quis odit hic porro similique dolore eveniet fugiat', 2650, 'corvette.jpg', 0, 0, 72, 1, '2019-07-16 03:45:14', '2019-07-23 01:04:55', 0),
(62, 3, 'Cutty Sark', 'Revell Cutty Sark 96th Scale Plastic Model Ship Kit', 3000, 'cutty.jpg', 0, 0, 35, 1, '2019-07-16 04:20:09', '2019-07-23 01:39:53', 0),
(82, 3, 'Titanic RMS', 'This hundredth anniversary kit features detailed hull and deck structures; lifeboats with davits; cargo hoists\r\nDetailed decks with wood plank structure\r\n\r\nIncludes a display stand\r\nWaterslide decals', 3999, 'titanic.jpg', 0, 0, 10, 1, '2019-07-23 02:22:07', '2019-07-23 03:22:12', 1),
(81, 1, 'Audi DTM', 'Audi DTM racing 2009 model', 3599, 'audi_main.jpg', 0, 0, 18, 1, '2019-07-21 03:47:25', '2019-07-23 02:41:00', 0);

-- --------------------------------------------------------

--
-- Stand-in structure for view `viewgalerijatest`
-- (See below for the actual view)
--
DROP VIEW IF EXISTS `viewgalerijatest`;
CREATE TABLE IF NOT EXISTS `viewgalerijatest` (
`id` int(4)
,`naziv` varchar(30)
,`glavna_slika` varchar(100)
,`mala_slika` varchar(50)
,`kategorija` varchar(30)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `viewkomentari`
-- (See below for the actual view)
--
DROP VIEW IF EXISTS `viewkomentari`;
CREATE TABLE IF NOT EXISTS `viewkomentari` (
`korisnik_ime` varchar(30)
,`korisnik_id` int(3)
,`model_id` int(3)
,`komentar_id` int(3)
,`komentar_sadrzaj` text
,`komentar_vreme` timestamp
,`komentar_obrisan` int(1)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `viewmodeli2`
-- (See below for the actual view)
--
DROP VIEW IF EXISTS `viewmodeli2`;
CREATE TABLE IF NOT EXISTS `viewmodeli2` (
`id` int(4)
,`naziv` varchar(30)
,`opis` text
,`slika` varchar(100)
,`cena` int(5)
,`pregledi` int(3)
,`lajk` int(4)
,`dislajk` int(4)
,`dostupan` int(1)
,`vreme` timestamp
,`obrisan` int(1)
,`kategorija` varchar(30)
);

-- --------------------------------------------------------

--
-- Structure for view `viewgalerijatest`
--
DROP TABLE IF EXISTS `viewgalerijatest`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `viewgalerijatest`  AS  select `modeli`.`id` AS `id`,`modeli`.`model_naziv` AS `naziv`,`modeli`.`model_slika` AS `glavna_slika`,`galerije`.`naziv_slike` AS `mala_slika`,`kategorije`.`kategorija` AS `kategorija` from ((`modeli` join `kategorije` on((`modeli`.`model_kategorija` = `kategorije`.`id`))) join `galerije` on((`modeli`.`id` = `galerije`.`model_id`))) ;

-- --------------------------------------------------------

--
-- Structure for view `viewkomentari`
--
DROP TABLE IF EXISTS `viewkomentari`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `viewkomentari`  AS  select `korisnici`.`korisnik_ime` AS `korisnik_ime`,`komentari`.`korisnik_id` AS `korisnik_id`,`komentari`.`model_id` AS `model_id`,`komentari`.`komentar_id` AS `komentar_id`,`komentari`.`komentar_sadrzaj` AS `komentar_sadrzaj`,`komentari`.`komentar_vreme` AS `komentar_vreme`,`komentari`.`komentar_obrisan` AS `komentar_obrisan` from (`korisnici` join `komentari` on((`korisnici`.`id` = `komentari`.`korisnik_id`))) ;

-- --------------------------------------------------------

--
-- Structure for view `viewmodeli2`
--
DROP TABLE IF EXISTS `viewmodeli2`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `viewmodeli2`  AS  select `modeli`.`id` AS `id`,`modeli`.`model_naziv` AS `naziv`,`modeli`.`model_opis` AS `opis`,`modeli`.`model_slika` AS `slika`,`modeli`.`model_cena` AS `cena`,`modeli`.`model_pregledi` AS `pregledi`,`modeli`.`model_lajk` AS `lajk`,`modeli`.`model_dislajk` AS `dislajk`,`modeli`.`model_dostupan` AS `dostupan`,`modeli`.`model_vreme` AS `vreme`,`modeli`.`model_obrisan` AS `obrisan`,`kategorije`.`kategorija` AS `kategorija` from (`modeli` join `kategorije` on((`modeli`.`model_kategorija` = `kategorije`.`id`))) ;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
