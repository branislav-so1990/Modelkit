<?php
$db = @mysqli_connect('localhost','root','','newproject');

if(mysqli_connect_error()){
    echo "Greska prilikom konekcije na bazu!<br>".mysqli_connect_error();
    exit();
}
mysqli_query($db, "SET NAMES UFT8");

?>
   
   <div class="top5Wrapper">
       <p>Trenutno<br>
           <span>Najpopularnije</span></p>

       <div class="topProducts">
           <?php
        $upit = "SELECT * from viewmodeli2 WHERE obrisan=0 ORDER BY pregledi DESC LIMIT 4";
        $rezultat = mysqli_query($db,$upit);
        $i = 1;
        while($red = mysqli_fetch_object($rezultat)){
            echo "<div class='topProduct' id='top".$i."'>
                    <div class='productPicture'> 
                        <img src='images/models/$red->slika'>
                        <a ng-click='prikaziModel($red->id)' style='cursor:pointer'>Vidi detalje</a>
                    </div>
                    <a class='banner'>Kategorija $red->kategorija</a>
                    <div class='productDescription'>
                        <a>$red->naziv</a>
                        <p>$red->vreme</p>
                        <p>$red->opis...</p>
                    </div>
                 </div>"; $i++;
        }?>
       </div><!-- end of .topProducts -->
   </div><!-- end of .top5Wrapper -->