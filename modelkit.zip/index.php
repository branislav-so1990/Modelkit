<?php session_start()?>
<!DOCTYPE html>
<html lang="en" ng-app="myModule">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width" , initial-scale=1, user-scalable="no" . />
    <title>Modelkit</title>
    <link rel="shortcut icon" href="images/web/icon.ico">
    <!-- Leaflet CSS za mape-->
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.5.1/dist/leaflet.css"
    integrity="sha512-xwE/Az9zrjBIphAcBb3F6JVqxf46+CDLwfLMHloNu6KEQCAWi6HcDUbeOfBIptF7tcCzusKFjFw2yuvEpDL9wQ=="
    crossorigin=""/>
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">
    <link href="https://fonts.googleapis.com/css?family=Comfortaa:400,500,700&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Anton" rel="stylesheet">
    <link rel="stylesheet" href="css/style.css">
    <script src="javaScript/biblioteke/jquery-3.4.0.min.js"></script>
    <script src="javaScript/biblioteke/angular.js"></script>
    <script src="javaScript/animacije.js"></script>
    <script src="javaScript/3modeliObrada.js"></script>
    <script src="javaScript/prijava.js"></script>
    <script src="javaScript/komentari.js"></script>
    <script src="javaScript/kontakt.js"></script>
    
</head>

<body ng-controller="myController">
    <!---------- Loading animation ----------->

    <div class="loader">
        <img src="images/web/loading.gif">
    </div>

    <!---------- Header ----------->

    <?php include_once('_header.php')?>

    <div class="wrapper">
        <!---------- Hero ----------->

        <div class="hero">
            <img src="images/web/hero.jpg" alt="hero">
            <div class="heroDetails">
                <a>Prodaja plastičnih modela</a> <br>
                <button><a href="https://www.google.com/maps/place/ITAcademy/@44.8514949,20.3945744,16z/data=!4m13!1m7!3m6!1s0x475a7aa9b8caf41b:0x4dd2cda9cc07c41f!2sHajduk-Veljkov+venac,+Beograd!3b1!8m2!3d44.8064477!4d20.4576536!3m4!1s0x0:0x6d6130bffc362462!8m2!3d44.8485481!4d20.4047549" target="_blank" style="color:white; text-decoration: none"><i class="fas fa-map-marker-alt iconH"></i>Cara Dušana bb,  Zemun</a></button><br>
                <button><i class="far fa-envelope iconH"></i>modelkit@gmail.com</button><br>
                <button><i class="fas fa-phone iconH"></i>+381/64 1112233</button><br>
            </div><!-- end of .heroDetails -->
        </div><!-- end of .hero -->

        <!---------- Top 5 products ----------->

        <?php include_once("_top5.php") ?>

        <!---------- Glavni sadrzaj ---------->
        {{test}}
        <div class="mainWrapper">
            <div class="leftWrapper">

                <!---- Prikaz filtera ---->

                <div class="filteri">
                    prikazan broj modela:
                    <input type="number" ng-model="brStrana" min="1" max="{{ukupno}}" step="1">
                    od: {{ukupno}}<br><br>

                    <input type="radio" name="prikazi" checked ng-model="kategorija" id="sve">
                    <label for="sve">Sve kategorije</label>
                    <input type="radio" name="prikazi" value="avioni" ng-model="kategorija" id="avio">
                    <label for="avio">Avioni</label>
                    <input type="radio" name="prikazi" value="brodovi" ng-model="kategorija" id="brod">
                    <label for="brod">Brodovi</label>
                    <input type="radio" name="prikazi" value="automobili" ng-model="kategorija" id="auto">
                    <label for="auto">Automobili</label>
                    <br>
                </div>


                <!-------- Prikaz svih modela ----->

                <div class="modelsWrapper">
                    <article class="mainKategorija" ng-repeat="model in modeli | limitTo:brStrana | filter:search | filter:kategorija">

                        <div class="slika">
                            <img ng-src='images/models/{{model.slika}}'>
                            <a id="readMore" ng-click='prikaziModel(model.id)'>Vidi detalje</a>
                            <p class="banner">Kategorija: {{model.kategorija}}</p>
                        </div>
                        <a ng-click='prikaziModel(model.id)'>{{model.naziv}}</a>
                        <p>{{model.opis | limitTo:100}}...</p>
                    </article><!-- end of .mainKategorija -->
                </div> <!-- end of .modelsWrapper -->
            </div> <!-- end of .leftWrapper -->


            <!---------- Sidebar sadrzaj -------->
            <div class="sidebarWrapper">
                <input type='text' id='pretraga' placeholder='Pretraži naziv...' ng-model='search.naziv'>
                <?php include_once("_sidebar.php") ?>
            </div><!-- end of .mainWrapper -->

            <!------ back to top button ------>

            <p class="backToTop"><i class="fas fa-chevron-up"></i></p>
        
        </div><!-- end of .wrapper -->


        <!------------- Footer ------------>
        <?php include_once("_footer.php") ?>
        
</body>
</html>

