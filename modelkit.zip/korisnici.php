<?php
session_start();
$db = @mysqli_connect('localhost','root','','newproject');
if(mysqli_connect_error()){
    echo "Greska prilikom konekcije na bazu!<br>".mysqli_connect_error();
    exit();
}
mysqli_query($db, "SET NAMES UTF8");

//PROVERA STATUSA
if(!isset($_SESSION['user']) AND !isset($_SESSION['status'])){
    echo "Morate biti prijavljeni!<br><br>";
    echo "<img src='../images/web/crash.jpg'>";
    exit();
}
else if($_SESSION['status']!='admin'){
    echo "Samo administrator ima pravo pristupa!<br>";
    echo "<img src='../images/web/crash.jpg'>";
    exit();
}

?>
<!DOCTYPE html>
<html lang="en" ng-app="modulKorisnici">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width", initial-scale=1, user-scalable="no"./>
    <title>Modelkit | Korisnici</title>
    <link rel="shortcut icon" href="images/web/icon.ico">
    <!-- Leaflet CSS za mape-->
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.5.1/dist/leaflet.css"
   integrity="sha512-xwE/Az9zrjBIphAcBb3F6JVqxf46+CDLwfLMHloNu6KEQCAWi6HcDUbeOfBIptF7tcCzusKFjFw2yuvEpDL9wQ=="
   crossorigin=""/>
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">
    <link href="https://fonts.googleapis.com/css?family=Comfortaa:400,500,700&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Anton" rel="stylesheet">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/model_detalji.css">
    <link rel="stylesheet" href="css/korisnicki_profil.css">
    <script src="javaScript/biblioteke/jquery-3.4.0.min.js"></script>
    <script src="javaScript/biblioteke/angular.js"></script>
    <script src="javaScript/prijava.js"></script>
    <script src="javaScript/animacije.js"></script>
    <script src="javaScript/korisnici.js"></script>
</head>
<body> 
  
    <!---------- Loading ----------->
        
       <div class="loader">
            <img src="images/web/loading.gif">
        </div>
    
    <!---------- Header ----------->  
   
    <?php include_once("_header.php")?>
       
       
        
    <div class="wrapper">
        
        <!------- Prikaz Korisnickog panela ------->
               
        <div class="mainWrapper">
            <div class="leftWrapper">
               <div class="goBackBtn">
                   <a href="index.php">Vrati se nazad</a>
               </div>
               
               <div class="dodajProizvod" ng-controller="kontrolerKorisnici">
                  
                <h1>Registrovani korisnici</h1>
                <input type="text" ng-model="pretraga" placeholder="Pronađi korisnika">
                
                <input type="radio" checked name="filter" id='svi' ng-model="filteri">
                <label for="svi">Svi</label>
                <input type="radio" name="filter" value="admin" id='admin' ng-model="filteri">
                <label for="admin">Admin</label>
                <input type="radio" name="filter" value="korisnik" id='korisnik' ng-model="filteri">
                <label for="korisnik">Korisnik</label>
                <input type="radio" name="filter" value="15" id='nevalidan' ng-model="filteri">
                <label for="nevalidan">Nisu validni</label>
                
                <table>
                    <tr>
                        <th colspan="2">Korisnik - {{ukupno}}</th>
                        <th>E-mail</th>
                        <th>Validan</th>
                        <th>Status</th>
                        <th colspan="2">Opcije</th>
                    </tr>
                    <tr ng-repeat="korisnik in korisnici | filter:pretraga | filter:filteri">
                        <td>{{korisnik.korisnik_prezime}}</td>
                        <td>{{korisnik.korisnik_ime}}</td>
                        <td>{{korisnik.korisnik_email}}</td>
                        <td>{{korisnik.korisnik_validan == 1 ? 'jeste' : 'nije'}}</td>
                        <td>{{korisnik.korisnik_status}}</td>
                        <td><button ng-click='izmeni(korisnik.id)'>Izmeni</button></td>
                        <td><button ng-click='obrisi(korisnik.id)'>Obriši</button></td>
                    </tr>
                </table><br>
                
                <div class="izmena" style="display:none">
                    <h1>Izmeni korisnika</h1>
                    <label for="korID">ID</label>
                    <input type="text" id="korID" ng-model='id' readonly>
                    <label for="korprezime">Prezime:</label>
                    <input type="text" id="korprezime" ng-model='prezime'>
                    <label for="korime">Ime:</label>
                    <input type="text" id="ikorme" ng-model='ime'>
                    <label for="koremail">E-mail:</label>
                    <input type="text" id="koremail" ng-model='email' readonly>
                    <label for="korstatus">Status:</label>
                    <select ng-model="status" id="korstatus">  
                            <option value="admin">Administrator</option>
                            <option value="korisnik">Korisnik</option>
                    </select><br>
                    <input type="button" ng-click='sacuvajIzmene(odgovor[0].id)' value='Sačuvaj izmene'>
                </div>
                
            </div><!-- end of .dodajProizvod -->
 
            </div> <!-- end of .leftWrapper -->

           
           
           
            <!---------- Sidebar sadrzaj -------->
            <div class="sidebarWrapper">
            <?php include_once("_sidebar.php") ?>
                              
        </div><!-- end of .mainWrapper --> 
        
        
        
        
        <!------ back to top button ------>
        
        <p class="backToTop"><i class="fas fa-chevron-up"></i></p>

        
    </div><!-- end of .wrapper -->
    
    
    <!------------- Footer ------------>
    <?php include_once("_footer.php") ?>
    
</body>
</html>