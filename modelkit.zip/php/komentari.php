<?php
include_once("classLog.php");
$db = @mysqli_connect('localhost','root','','newproject');
if(mysqli_connect_error()){
    echo "Greška prilikom konekcije na bazu!<br>".mysqli_connect_error();
    exit();
}
mysqli_query($db, "SET NAMES UTF8");

$metoda = $_SERVER["REQUEST_METHOD"];

switch($metoda){
    
    case "GET" :
        //--- BRISANJE komentara ---
        if(isset($_GET['id'])){
            $id = mysqli_real_escape_string($db, $_GET['id']);
            $id = strip_tags($id);
            $upit = "UPDATE komentari SET komentar_obrisan = 1 WHERE komentar_id='{$_GET['id']}'"; 
            $rezultat = mysqli_query($db, $upit);
            if(mysqli_error($db)){
                echo "Greska! ".mysqli_error($db);
                exit();
            }
            else {
                echo "Uspešno obrisan komentar!";
                session_start();
                Log::upisi("komentari.txt", "Uspešno obrisan komentar - ID: ".$_GET['id']." | od korisnika: ".$_SESSION['user']);
            }
        }
        if(isset($_GET['prikazi'])) {
            $idModela = mysqli_real_escape_string($db, $_GET['id']);
            $idModela = strip_tags($idModela);
            echo $idModela;
        }
        
        
        break;
    
    case "POST" :
        
            //-- DODAVANJE komentara --
            session_start();
            $idKorisnika = mysqli_real_escape_string($db, $_SESSION['id']);
            $idModela = mysqli_real_escape_string($db, $_GET['id']);
            $idModela = strip_tags($idModela);
            $sadrzaj = mysqli_real_escape_string($db, $_POST['sadrzaj']); 
            $sadrzaj = strip_tags($sadrzaj);

            $upit = "INSERT INTO komentari (korisnik_id, model_id,komentar_sadrzaj) VALUES ('{$idKorisnika}','{$idModela}','{$sadrzaj}')";
            $rezultat = mysqli_query($db, $upit);
            if(mysqli_error($db)) {
                echo "<b>Greška! </b>".mysqli_error($db);
                exit();
            }
            else {
                echo "<b>Uspešno dodat komentar!</b>";
                Log::upisi("komentari.txt", "Uspešno dodat komentar - ID modela: ".$idModela." | od korisnika: ".$_SESSION['user']);
            }
        
        
        
}   


?>