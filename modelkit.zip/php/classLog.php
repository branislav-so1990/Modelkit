<?php
class Log {
    static function upisi ($datoteka, $text){
        $textzaUpis = date("d.m.Y H:i", time())." - ".$text."\r\n";
        $f = fopen ("../admin/Logs/".$datoteka, "a");
        fwrite ($f, $textzaUpis);
        fclose ($f);
    }
    static function upisiAdmin ($datoteka, $tekst) {
		$tekstZaUpis=date("d.m.Y H:i")." - ".$tekst."\r\n";
		$f=fopen ("admin/Logs/".$datoteka, "a");
		fwrite ($f, $tekstZaUpis);
		fclose ($f);
	}
}
?>