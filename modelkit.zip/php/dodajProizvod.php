<?php
include_once("classLog.php");
$db = @mysqli_connect('localhost','root','','newproject');

if(mysqli_connect_error()){
    echo "Greška prilikom konekcije na bazu!<br>".mysqli_connect_error();
    exit();
}
mysqli_query($db, "SET NAMES UTF8");


//Dodavanje modela u bazu - mora da ima NAME u HTML-u
if(isset($_POST['nazivProizvoda']) AND isset($_POST['kategorijaProizvoda']) AND isset($_POST['cenaProizvoda']) AND isset($_FILES['slikaProizvoda']['name'])) {
    
    $naziv = mysqli_real_escape_string($db, $_POST['nazivProizvoda']);
    $naziv = strip_tags($naziv);
    $kategorija = mysqli_real_escape_string($db, $_POST['kategorijaProizvoda']);
    $kategorija = strip_tags($kategorija);
    $cena = $_POST['cenaProizvoda'];
    $opis = mysqli_real_escape_string($db, $_POST['opisProizvoda']);
    $opis = strip_tags($opis);
    $imeSlike = mysqli_real_escape_string($db, $_FILES['slikaProizvoda']['name']);
    $imeSlike = strip_tags($imeSlike);
    $tempIme = $_FILES['slikaProizvoda']['tmp_name'];
    
    
    //provera da li je fajl slika
    $provera = getimagesize($tempIme);
    if($provera === false){
        echo "<b>Fajl nije u formatu slike!</b>";
        exit();
    }
    //provera velicine slike
    if($_FILES['slikaProizvoda']['size'] > 500000) { // >500kb
        echo "<b>Slika ne sme biti veća od 500kb!</b>";
        exit();
    }
    $upit = "INSERT INTO modeli (model_naziv, model_kategorija, model_cena, model_slika, model_opis) VALUES ('{$naziv}','{$kategorija}','{$cena}','{$imeSlike}','{$opis}')";
    $rezultat = mysqli_query($db, $upit);
    
    if(mysqli_error($db)) {
        echo "<b>Greška na serveru! <br></b>".mysqli_error($db);
        exit();
    }
    if(move_uploaded_file($tempIme, "../images/models/".$imeSlike)) {
        
        // Ako postoje dodatne slike
        if(isset($_FILES['dodatneSlike']['name']) AND $_FILES['dodatneSlike']['name'][0]!="") {
            
            $idModela = mysqli_insert_id($db); //dodavanje ID od modela
            for($i=0; $i< count($_FILES['dodatneSlike']['name']); $i++) {
                
                //var_dump($_FILES);
                $imeDodatneSlike[$i] = $_FILES['dodatneSlike']['name'][$i];
                
                if(!move_uploaded_file($_FILES['dodatneSlike']['tmp_name'][$i], "../images/models/".$_FILES['dodatneSlike']['name'][$i])) {
                    echo "Greška sa prebacivanjem dodatne slike!";
                    exit();
                }
                else {
                    $upit = "INSERT INTO galerije (model_id, naziv_slike) VALUES ('{$idModela}','{$imeDodatneSlike[$i]}')";
                    $rezultat = mysqli_query($db, $upit);
                    if(mysqli_error($db)) {
                        echo "Greska! ".mysqli_error($db);
                        exit();
                    }
                }
            }
            echo "<b>Uspešno snimljen model sa ".$i." dodatne slike!</b>";
            Log::upisi("proizvodi.txt", "Uspešno dodavanje proizvoda - Naziv: ".$naziv." | Kategorija: ".$kategorija." | Cena: ".$cena." rsd | od korisnika: ");
            exit();
        }
        else {
            echo "<b>Uspešno snimljen model!</b>";
            session_start();
            Log::upisi("proizvodi.txt", "Uspešno dodavanje proizvoda - Naziv: ".$naziv." | Kategorija: ".$kategorija." | Cena: ".$cena." rsd | od korisnika: ".$_SESSION['user']);
        }
    }
    else {
        echo "<b>Greška prilikom uploada glavne slike!</b>";
        exit();
    }      
}
else {
    echo "</b>Niste popunili sve podatke!</b>";
    exit();
}
?>