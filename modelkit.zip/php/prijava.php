<?php
include_once("classLog.php");
$db = @mysqli_connect('localhost','root','','newproject');

if(mysqli_connect_error()){
    echo "Greška prilikom konekcije na bazu!<br>".mysqli_connect_error();
    exit();
}
mysqli_query($db, "SET NAMES UTF8");



//--- Logovanje postojeceg korisika ---

if(isset($_POST['Logime']) AND isset($_POST['Loglozinka'])) {
    
    $ime = mysqli_real_escape_string($db, $_POST['Logime']);
    $ime = strip_tags($ime);
    $lozinka = mysqli_real_escape_string($db, $_POST['Loglozinka']);
    $lozinka = strip_tags($lozinka);
    
    if($ime!="" AND $lozinka!=""){
        
        if(strpos($ime, " ")!==false OR strpos($lozinka, " ")!==false) {
            echo "Zabranjen razmak!";
            exit();
        }
        
        $upit = "SELECT * FROM korisnici WHERE korisnik_obrisan=0 AND korisnik_ime='{$ime}' LIMIT 1";
        $rezultat = mysqli_query($db, $upit);
        if(!mysqli_error($db)){
            if(mysqli_num_rows($rezultat)==1){
                
                $red = mysqli_fetch_object($rezultat);
                if($red->korisnik_validan != 1) {
                    echo "Morate prvo validirati e-mail !";
                    exit();
                }
                
                $hash = $red->korisnik_lozinka;
                if(password_verify($lozinka, $hash)){
                    session_start();
                    $_SESSION['user'] = $red->korisnik_ime." ".$red->korisnik_prezime;
                    $_SESSION['status'] = $red->korisnik_status;
                    $_SESSION['id'] = $red->id;
                    //ako postoji .php znamo da je odgovor prosao!
                    
                    Log::upisi ("logovanje.txt", "Uspešno logovanje - Korisnik: ".$red->korisnik_ime." ".$red->korisnik_prezime." | status: ".$red->korisnik_status);
                    echo "Uspešna prijava!";
                    echo ".php";
                }
                else {
                    Log::upisi ("logovanje.txt", "Neuspešno logovanje - Korisnik: ".$ime." | lozinka: ".$lozinka);
                    echo "Lozinka nije ispravna!";
                }
                    
            }
            else {
                Log::upisi ("logovanje.txt", "Neuspešno logovanje - Nepostojeci korisnik: ".$ime." | lozinka: ".$lozinka." | IP adresa: (".$_SERVER['REMOTE_ADDR'].")");
                echo "Korisnik ".$ime." ne postoji!";
            }
                
        }
        else
            echo "Došlo je do greške!<br>".mysqli_error($db);
    }
    else
        echo "Niste popunili sva polja!";
}





//--- Registracija novog korisnika ---

if(isset($_POST['ime']) AND isset($_POST['prezime']) AND isset($_POST['lozinka']) AND isset($_POST['email'])){
    $ime = mysqli_real_escape_string($db, $_POST['ime']);
    $ime = strip_tags($ime);
    $prezime = mysqli_real_escape_string($db, $_POST['prezime']);
    $prezime = strip_tags($prezime);
    $lozinka = mysqli_real_escape_string($db, $_POST['lozinka']);
    $lozinka = strip_tags($lozinka);
    $ponovljenalozinka = mysqli_real_escape_string($db, $_POST['ponovljenalozinka']);
    $ponovljenalozinka = strip_tags($ponovljenalozinka);
    $email = mysqli_real_escape_string($db, $_POST['email']);
    $email = strip_tags($email);
    $vreme = time();
    $explode = explode("@", $email);

    if($ime!="" OR $prezime!="" OR $lozinka!="" OR $ponovljenalozinka!="" OR $email!="") {
        
        if(strpos($ime,"'")!==false OR strpos($ime,'"')!==false OR strpos($ime,"<")!==false){
            echo "Nedozvoljeni simboli u imenu!";
            exit();
        }
        if(strpos($prezime,"'")!==false OR strpos($prezime,'"')!==false OR strpos($prezime,"<")!==false){
            echo "Nedozvoljeni simboli u prezimenu!";
            exit();
        }//provera e-maila
        if(sizeof($explode)!=2){
            echo "Unesite ispravnu e-mail adresu (@)!";
            exit();
        }
        //provera da li je email vec zauzet
        $upit = "SELECT * FROM korisnici WHERE korisnik_email='{$email}' LIMIT 1";
        $rezultat = mysqli_query($db, $upit);
        if(mysqli_num_rows($rezultat)==1) { // vec postoji email
            echo "Takav e-mail već postoji!";
            exit();
        }
        //Upisivanje korisnika u bazu
        $hash = password_hash($lozinka, PASSWORD_BCRYPT);
        $upit = "INSERT INTO korisnici (korisnik_ime, korisnik_prezime, korisnik_lozinka, korisnik_email, korisnik_validan) VALUES ('{$ime}','{$prezime}','{$hash}','{$email}',$vreme)";
        mysqli_query($db, $upit);
        if(mysqli_error($db))
            echo "Greška prilikom registracije!<br>".mysqli_error($db);
        else{
            $poruka = "<a href='validacija.php?email=$email&vreme=$vreme'>ovde!</a>";
            @mail($email, "Potvrda e-maila", $poruka);
            echo "Uspešno ste se registrovali!<br>";
            echo "Potvrdite Vaš e-mail: ";
            echo $poruka;
            Log::upisi("registracije.txt", "Uspešna registracija - Ime: ".$ime.", Prezime: ".$prezime." | E-mail: ".$email." | Lozinka: ".$lozinka);
        }
    }
    else
        echo "Niste popunili sva polja!";
    }
    // end of registracija korisnika





?>