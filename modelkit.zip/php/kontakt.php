<?php
$db = @mysqli_connect('localhost','root','','newproject');

$ime = mysqli_real_escape_string($db, $_POST['ime']);
$ime = strip_tags($ime);
$email = mysqli_real_escape_string($db, $_POST['email']);
$email = strip_tags($email);
$sadrzaj = mysqli_real_escape_string($db, $_POST['sadrzaj']);
$sadrzaj = strip_tags($sadrzaj);
$explode = explode("@", $email);
$explode2 = explode(".", $email);

if(!empty($ime) OR !empty($email) OR !empty($sadrzaj)){
    
    if(sizeof($explode)!=2 OR sizeof($explode2)!=2){
        echo "E-mail adresa nije validna!";
        exit();
    }
    else
        echo "Uspešno poslato!";
}
else {
    echo "Niste popunili sva polja!";
}








?>
