<?php
include_once("classLog.php");
$db = @mysqli_connect('localhost','root','','newproject');
if(mysqli_connect_error()){
    echo "Greska prilikom konekcije na bazu!<br>".mysqli_connect_error();
    exit();
}
mysqli_query($db, "SET NAMES UTF8");

if(isset($_POST['id'])){
    
    $id = $_POST['id'];
    $ime = $_POST['ime'];
    $prezime = $_POST['prezime'];
    
    if(isset($_POST['novaLozinka']) AND isset($_POST['novaLozinka2']) AND $_POST['novaLozinka']!="" AND $_POST['novaLozinka2']!="") {
        $novaLozinka = $_POST['novaLozinka'];
        $novaLozinka2 = $_POST['novaLozinka2'];
        if($novaLozinka !== $novaLozinka2){
            echo "Lozinke nisu iste!";
            exit();
        }
        $hash = password_hash($novaLozinka, PASSWORD_BCRYPT);
        $upit = "UPDATE korisnici SET korisnik_ime='{$ime}', korisnik_prezime='{$prezime}', korisnik_lozinka='{$hash}' WHERE id='{$id}'";
        $rezultat = mysqli_query($db, $upit);
        if(mysqli_error($db)){
            echo "Greška! ".mysqli_error($db);
            exit();
        }
        else
            echo "Uspešno sačuvano sa novom lozinkom!";
        exit();
    }
    
    //Ako nije menjana lozinka
    if($id!="" OR $ime!="" OR $prezime!=""){
        $upit = "UPDATE korisnici SET korisnik_ime='{$ime}', korisnik_prezime='{$prezime}' WHERE id='{$id}'";
        $rezultat = mysqli_query($db, $upit);
        if(mysqli_error($db)){
            echo "Greška! ".mysqli_error($db);
            exit();
        }
        else{
            Log::upisi ("logovanje.txt", "Izmenjeni podaci o korisniku: ID ".$id." | ".$ime." ".$prezime);
            echo "Uspešno izmenjeno!";
        }
            
    }
    else{
        echo "Niste popunili sva polja!";
        exit();
    }
        
    
}


?>