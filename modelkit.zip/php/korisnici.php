<?php
$db = @mysqli_connect('localhost','root','','newproject');
if(mysqli_connect_error()){
    echo "Greska prilikom konekcije na bazu!<br>".mysqli_connect_error();
    exit();
}
mysqli_query($db, "SET NAMES UTF8");

if(isset($_GET['funkcija']) AND isset($_GET['id'])){
    $funkcija = $_GET['funkcija'];
    $id = $_GET['id'];
    
    if($funkcija == 'brisanje'){
        $upit = "UPDATE korisnici SET korisnik_obrisan=1 WHERE id='{$id}'";
        $rezultat = mysqli_query($db, $upit);
        if(mysqli_error($db)){
            echo"Greška!";
            echo mysqli_error($db);
            exit();
        } 
        echo "Uspešno obrisan korisnik!";
    }
    else if($funkcija == 'izmena'){
        $upit = "SELECT * FROM korisnici WHERE id='{$id}' LIMIT 1";
        $rezultat = mysqli_query($db, $upit);
        if(mysqli_error($db)){
            echo"Greška!";
            echo mysqli_error($db);
            exit();
        } 
        else{
            $odg = mysqli_fetch_all($rezultat, MYSQLI_ASSOC);
            echo JSON_encode($odg, 256);
        }
    }
    else if($funkcija == 'sacuvaj'){
        $data = JSON_decode(file_get_contents('php://input'));
        $upit = "UPDATE korisnici SET korisnik_ime='{$data->ime}', korisnik_prezime='{$data->prezime}', korisnik_email='{$data->email}', korisnik_status='{$data->status}' WHERE id='{$id}'";
        $rezultat = mysqli_query($db, $upit);
        if(mysqli_error($db))
            echo "Greška! ".mysqli_error($db);
        else {
            echo "Uspešno izmenjen korisnik!";
        }
    }
}
else {
    $upit = "SELECT * FROM korisnici WHERE korisnik_obrisan=0 ORDER by id DESC";
    $rezultat = mysqli_query($db, $upit);
    if(mysqli_error($db))
        echo mysqli_error($db);
    $odg = mysqli_fetch_all($rezultat, MYSQLI_ASSOC);
    echo JSON_encode($odg, 256);
}



?>