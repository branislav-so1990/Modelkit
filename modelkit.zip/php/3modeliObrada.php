<?php
include_once("classLog.php");
$db = @mysqli_connect('localhost','root','','newproject');
if(mysqli_connect_error()){
    echo "Greska prilikom konekcije na bazu!<br>".mysqli_connect_error();
    exit();
}
mysqli_query($db, "SET NAMES UTF8");
$metoda = $_SERVER['REQUEST_METHOD'];


switch($metoda) {
        
    case 'GET':
        //popunjavanje polja za IZMENU proizvoda
        if(isset($_GET['id'])){
            $id = mysqli_real_escape_string($db, $_GET['id']);
            $id = strip_tags($id);
            $upit = "SELECT * FROM modeli WHERE id='{$id}'";
            $rezultat = mysqli_query($db, $upit);
            $odg = mysqli_fetch_all($rezultat, MYSQLI_ASSOC);
            echo JSON_encode($odg, 256);

        }else {
            //prikaz svih modela na pocetnoj stranici
            $upit = "SELECT * FROM viewModeli2 WHERE obrisan=0 ORDER BY id DESC";
            $rezultat = mysqli_query($db, $upit);
            $odg = mysqli_fetch_all($rezultat, MYSQLI_ASSOC);
            echo JSON_encode($odg, 256);
        }
        break;
        
        
    
    case 'POST':
        //Brisanje proizvoda
        if(isset($_GET['id']) AND !isset($_GET['izmeni'])){
            $id = mysqli_real_escape_string($db, $_GET['id']);
            $id = strip_tags($id);
            $upit = "UPDATE modeli SET model_obrisan=1 WHERE id='{$id}'";
            $rezultat = mysqli_query($db, $upit);
            if(!mysqli_error($db)) {
                echo "Uspešno obrisan proizvod!";
                session_start();
                Log::upisi("proizvodi.txt", "Uspešno brisanje proizvoda - ID: ".$id." | od korisnika: ".$_SESSION['user']);
            }
            else {
                echo "Greska na serveru! ".mysqli_error($db);
                exit();
            }
        }
        
        //Izmena proizvoda - update
        if(isset($_GET['izmeni'])){
            $id = mysqli_real_escape_string($db, $_GET['id']);
            $id = strip_tags($id);
            $naziv = mysqli_real_escape_string($db, $_POST['nazivIzmena']);
            $naziv = strip_tags($naziv);
            $kategorija = $_POST['kategorijaIzmena'];
            $cena = $_POST['cenaIzmena'];
            $dostupan = $_POST['dostupanIzmena'];
            $opis = mysqli_real_escape_string($db, $_POST['opisIzmena']);
            $opis = strip_tags($opis);

            //Provere
            if($naziv=="" OR $kategorija==0 OR $cena==""){
                echo "<b>Niste popunili sva polja!</b>";
                exit();
            }

            $upit = "UPDATE modeli SET model_naziv='{$naziv}', model_kategorija='{$kategorija}', model_cena='{$cena}', model_dostupan='{$dostupan}', model_opis='{$opis}' WHERE id='{$id}'";
            $rezultat = mysqli_query($db, $upit);
            if(mysqli_error($db))
                echo "Greska! ".mysqli_error($db);
            else {
                echo "<b>Uspešno izmenjen proizvod!</b>";
                session_start();
                Log::upisi("proizvodi.txt", "Uspešno izmenjen proizvod - Naziv: ".$naziv." | Kategorija: ".$kategorija." | Cena: ".$cena." rsd | od korisnika: ".$_SESSION['user']);
            }
            exit();
        }
        break;
        
}



?>