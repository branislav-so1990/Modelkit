<?php
$db = @mysqli_connect('localhost','root','','newproject');
if(mysqli_connect_error()){
    echo "Greska prilikom konekcije na bazu!<br>".mysqli_connect_error();
    exit();
}

if(isset($_GET['id'])){
    $upit = "SELECT * FROM galerije WHERE id='{$_GET['id']}'";
    $rezultat = mysqli_query($db, $upit);
    $red = mysqli_fetch_object($rezultat);
    echo $red->naziv_slike;
}
else{
    echo "Nema ID";
}

?>