<?php
include_once("classLog.php");
$db = @mysqli_connect('localhost','root','','newproject');
if(mysqli_connect_error()){
    echo "Greska prilikom konekcije na bazu!<br>".mysqli_connect_error();
    exit();
}
mysqli_query($db, "SET NAMES UTF8");
$metoda = $_SERVER['REQUEST_METHOD'];


// Dodavanje modela u korpu
if(isset($_GET['id']) AND !isset($_GET['funkcija'])){
    session_start();
    $idKupca =  mysqli_real_escape_string($db, $_SESSION['id']);
    $idProizvoda =  mysqli_real_escape_string($db, $_GET['id']);
    $idProizvoda = strip_tags($idProizvoda);
    $upit = "INSERT INTO korpa (id_kupca, id_proizvoda) VALUES ('{$idKupca}','{$idProizvoda}')";
    $rezultat = mysqli_query($db, $upit);
    if(mysqli_error($db)) {
        echo "Greska! ".mysqli_error($db);
        exit();
    }
    else
        echo "Dodato u korpu!";
}

//--- OSTALE OPCIJE ---

if(isset($_GET['funkcija'])) {
    $funkcija = $_GET['funkcija'];

    if($funkcija=='sadrzaj'){
        session_start();
        $idKupca =  mysqli_real_escape_string($db, $_SESSION['id']);
        $upit = "SELECT korpa.*, modeli.model_naziv, modeli.model_cena, modeli.model_slika FROM korpa INNER JOIN modeli ON korpa.id_proizvoda = modeli.id WHERE id_kupca='{$idKupca}' AND kupljen=0 ORDER BY id DESC";
        $rezultat = mysqli_query($db, $upit);

        if(mysqli_error($db)){
            echo "Greska! ".mysqli_error($db);
            exit();
        }
        if(mysqli_num_rows($rezultat)==0)
            echo "Nemate proizvode u korpi!";
        else {

            while($red = mysqli_fetch_object($rezultat)){
                echo "<i>ID:".$red->id."<i><br><b>".$red->model_naziv."</b>, Cena: ".$red->model_cena." RSD<br><br>";
                echo "<img src='images/models/".$red->model_slika."'><br><br>";
                echo "<input type='button' id='korpaBtns' onclick='kupi($red->id)' value='Kupi'> <input type='button' onclick='ukloniIzKorpe($red->id)' value='Ukloni iz korpe' id='korpaBtns'>";
                echo "<br><hr>";


            }
            // Forma za podatke kupovine
                echo "<div class='formaZaKupovinu'>
                    <h1>Podaci za slanje</h1>
                    <label>ID kupovine:</label>
                    <input type='text' class='idKupovine' readonly>
                    <label>Vaše Ime:</label>
                    <input type='text' class='imeKupca' value='".$_SESSION['user']."'>
                    <label>Adresa za slanje:</label>
                    <input type='text' id='adresa'>
                    <label>Broj telefona:</label>
                    <input type='text' id='telefon'>
                    <div class='odg'></div><br>
                    <input type='button'  onclick='potvrdiKupovinu()' value='Potvrdi kupovinu'>
                    <input type='button' onclick='otkazi()' value='Otkaži'>
                </div>";
        }
    }

    if($funkcija=='kupljeno'){
        session_start();
        $idKupca =  mysqli_real_escape_string($db, $_SESSION['id']);
        $upit = "SELECT korpa.*, modeli.model_naziv, modeli.model_cena, modeli.model_slika FROM korpa INNER JOIN modeli ON korpa.id_proizvoda = modeli.id WHERE id_kupca='{$idKupca}' AND kupljen=1 ORDER BY id DESC";
        $rezultat = mysqli_query($db, $upit);
        if(mysqli_error($db)){
            echo "Greska! ".mysqli_error($db);
            exit();
        }
        if(mysqli_num_rows($rezultat)==0)
            echo "Još niste kupili ni jedan proizvod!";
        else {
            while($red = mysqli_fetch_object($rezultat)){
                echo "<b>".$red->model_naziv."</b>, Cena: ".$red->model_cena." RSD<br><br>";
                echo "<img src='images/models/".$red->model_slika."'><br><br>";
                echo "Vreme kupovine: ".$red->vreme_kupovine;
                echo "<br><hr>";
            }
        }
    }

    if($funkcija=='ukloni'){
        $idKupovine = mysqli_real_escape_string($db, $_POST['idKupovine']);
        $idKupovine = strip_tags($idKupovine);
        $upit = "DELETE FROM korpa WHERE id='{$idKupovine}'";
        $rezultat = mysqli_query($db, $upit);
    }


    if($funkcija=='kupi'){
        $idKupovine = mysqli_real_escape_string($db, $_POST['idKupovine']);
        $idKupovine = strip_tags($idKupovine);
        $ime = mysqli_real_escape_string($db, $_POST['ime']);
        $ime = strip_tags($ime);
        $adresa = mysqli_real_escape_string($db, $_POST['adresa']);
        $adresa = strip_tags($adresa);
        $telefon = mysqli_real_escape_string($db, $_POST['telefon']);
        $telefon = strip_tags($telefon);
        $upit = "UPDATE korpa SET kupljen=1, adresa='{$adresa}', telefon='{$telefon}' WHERE id='{$idKupovine}'";
        $rezultat = mysqli_query($db, $upit);
        if(mysqli_error($db)){
            echo "Greška! ".mysqli_error($db);
            exit();
        }
        else
            echo "Uspešno obavljena kupovina!";
            Log::upisi("kupljeno.txt", "Uspešna kupovina - ID: ".$idKupovine." | Kupio: ".$ime." | Telefon: ".$telefon);
    }
}


?>