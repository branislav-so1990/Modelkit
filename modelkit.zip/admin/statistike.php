<?php
session_start();
//PROVERA STATUSA
if(!isset($_SESSION['user']) AND !isset($_SESSION['status'])){
    echo "Morate biti prijavljeni!<br><br>";
    echo "<img src='../images/web/crash.jpg'>";
    exit();
}
else if($_SESSION['status']!='admin'){
    echo "Samo administrator ima pravo pristupa!<br>";
    echo "<img src='../images/web/crash.jpg'>";
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width", initial-scale=1, user-scalable="no"./>
    <title>Modelkit | Stats</title>
    <link rel="shortcut icon" href="images/web/icon.ico">
    <!-- Leaflet CSS za mape-->
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.5.1/dist/leaflet.css"
   integrity="sha512-xwE/Az9zrjBIphAcBb3F6JVqxf46+CDLwfLMHloNu6KEQCAWi6HcDUbeOfBIptF7tcCzusKFjFw2yuvEpDL9wQ=="
   crossorigin=""/>
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">
    <link href="https://fonts.googleapis.com/css?family=Comfortaa:400,500,700&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Anton" rel="stylesheet">
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="../css/model_detalji.css">
    <link rel="stylesheet" href="../css/korisnicki_profil.css">
    <script src="../javaScript/biblioteke/jquery-3.4.0.min.js"></script>
    <script src="../javaScript/biblioteke/angular.js"></script>
    <script src="../javaScript/angular_obrada.js"></script>
    <script src="../javaScript/prijava.js"></script>
    <script src="../javaScript/animacije.js"></script> 
    <script src="../javaScript/kontakt.js"></script>
</head>
<body>
   <!---------- Header ----------->  
   
    <header>
        <div class="logo">
            <img src="../images/web/modelkit_logo.png" alt="logo">
        </div>
        <nav>
            <ul>
                <li><a href="../index.php">Početna</a></li>
                <li><a id="contactUs">Kontakt</a></li>
                <?php
                if(isset($_SESSION['user'])){
                    echo "<li><a href='#' id='login' title='Pogledaj profil'>".$_SESSION['user']."</a></li>";
                    echo "<li><a href='korpa.php'><img src='../images/web/korpa.png' alt='korpa'> 0</a></li>";
                }
                else
                    echo "<li><a href='#' id='login'>Prijavi se</a></li>"
            ?>
            </ul>
            <img src="images/web/hamburger_menu.png" alt="menu">
        </nav>
    </header>
        
    <div class="wrapper"  ng-controller="mojKontroler">
        
    <!------- Prikaz Korisnickog panela ------->
               
    <div class="mainWrapper">
        <div class="leftWrapper">
            <div class="goBackBtn">
                <a href="../index.php">Vrati se nazad</a>
            </div>
               
            <div class="dodajProizvod">
                  
                <h1>Statistika</h1>
                
                <form action="#" method="post">
                    <select name="log" id="log">
                        <option value="0" selected>--Izaberite zapis--</option>
                        <option value="komentari.txt" >Prikazi komentare</option>
                        <option value="proizvodi.txt" >Prikazi proizvode</option>
                        <option value="logovanje.txt" >Prikazi korisnike</option>
                        <option value="kupljeno.txt" >Prikazi kupljene proizvode</option>
                    </select><br>
                    <div class="odgovorStats"></div><br>
                    <?php
                        if(isset($_POST['log']) && $_POST['log']!="0")
                        {
                            $datoteka=$_POST['log'];
                            $tekst=file_get_contents("Logs/".$datoteka);
                            $tekst=str_replace("\r\n", "<br>", $tekst);
                            echo $tekst."<br>";
                        }
                    ?>
                    <input type="submit" value="Prikaži log"/>  
                </form>      
            </div><!-- end of .dodajProizvod -->
 
        </div> <!-- end of .leftWrapper -->

           
        <!---------- Sidebar sadrzaj -------->
        
        <div class="sidebarWrapper">
           
           
            <!------------ Prijava i Registracija korisnika ----------->

            <div class="userAccount">
                <div class="container">

                    <!------ Prijava ------>

                    <div class="prijava">
                        <?php
                if(isset($_SESSION['user'])){
                    echo "<p>Nalog korisnika</p>";
                    echo "<ul>
                            <li><img src='../images/web/korpa.png' width='25px'><a href='../korpa.php' class='admin'>Korpa</a></li>
                            <li><img src='../images/web/exit.png' width='25px'><a href='../index.php?odjava' class='admin'>Odjavi se</a></li>
                          </ul>";
                    
                    if(isset($_SESSION['status']) AND $_SESSION['status'] == "admin"){
                        echo "<h3>Administrator:</h3>";
                        echo "<ul>
                                <li><img src='../images/web/proizvod.png' width='25px'><a href='../dodajProizvod.php' class='admin'>Dodaj proizvod</a></li>
                                <li><img src='../images/web/user.png' width='25px'><a href='../korisnici.php' class='admin'>Korisnici</a></li>
                                <li><img src='../images/web/logs.png' width='25px'><a href='../admin/statistike.php' class='admin'>Statistike</a><br></li>
                              </ul>";
                    }
                }
                ?>
                </div><!-- end of .prijava -->

                </div><!-- end of .container -->
            </div><!-- end of .userAccount -->

        </div><!-- end of .sidebarWrapper -->
    </div><!-- end of .mainWrapper -->
        
        
        <!------ back to top button ------>
        
        <p class="backToTop"><i class="fas fa-chevron-up"></i></p>

    </div><!-- end of .wrapper -->
    
    
    <!------------- Footer ------------>
    <?php include_once("../_footer.php") ?>
    
</body>
</html>