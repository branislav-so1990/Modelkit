<?php
$db = @mysqli_connect('localhost','root','','newproject');

if(mysqli_connect_error()){
    echo "Greska prilikom konekcije na bazu!<br>".mysqli_connect_error();
    exit();
}
mysqli_query($db, "SET NAMES UTF8");


echo "<h1>Validacija e-maila</h1>";

if(isset($_GET['email']) AND isset($_GET['vreme'])){
    $email = $_GET['email'];
    $vreme = $_GET['vreme'];
    
    $upit = "UPDATE korisnici SET korisnik_validan=1 WHERE korisnik_email='{$email}' AND korisnik_validan='{$vreme}'";
    $rezultat = mysqli_query($db, $upit);
    if(mysqli_error($db))
        echo "Greska!<br>".mysqli_error($db)."<hr>";
    if(mysqli_affected_rows($db) == 1)
        echo "<h3>Uspešna validacija!</h3><br>
              Hvala što ste se prijavili!<hr>";
    else
        echo "<h3>Neušpesna validacija!</h3><hr>";  
}
else
    echo "Nema GET parametra!<br>";

echo "<a href='index.php'>Vrati se nazad</a>";
?>