<?php
session_start();
//PROVERA STATUSA
    if(!isset($_SESSION['user']) AND !isset($_SESSION['status'])){
        echo "Morate biti prijavljeni!<br><br>";
        echo "<img src='images/web/crash.jpg'>";
        exit();
    }

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width", initial-scale=1, user-scalable="no"./>
    <title>Modelkit | Podaci korisnika</title>
    <link rel="shortcut icon" href="images/web/icon.ico">
    <!-- Leaflet CSS za mape-->
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.5.1/dist/leaflet.css"
   integrity="sha512-xwE/Az9zrjBIphAcBb3F6JVqxf46+CDLwfLMHloNu6KEQCAWi6HcDUbeOfBIptF7tcCzusKFjFw2yuvEpDL9wQ=="
   crossorigin=""/>
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">
    <link href="https://fonts.googleapis.com/css?family=Comfortaa:400,500,700&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Anton" rel="stylesheet">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/model_detalji.css">
    <link rel="stylesheet" href="css/korisnicki_profil.css">
    <script src="javaScript/biblioteke/jquery-3.4.0.min.js"></script>
    <script src="javaScript/biblioteke/angular.js"></script>
    <script src="javaScript/prijava.js"></script>
    <script src="javaScript/animacije.js"></script> 
    <script src="javaScript/dodajProizvod.js"></script> 
    <script src="javaScript/kontakt.js"></script>
    <script src="javaScript/podaciKorisnika.js"></script>
</head>
<body > 
  
    <!---------- Loading ----------->
        
       <div class="loader">
            <img src="images/web/loading.gif">
        </div>
    
    <!---------- Header ----------->  
   
    <?php include_once("_header.php")?>
       
    <div class="wrapper">
        
        <!------- Prikaz Korisnickog panela ------->
               
        <div class="mainWrapper">
            <div class="leftWrapper">
               <div class="goBackBtn">
                   <a href="index.php">Vrati se nazad</a>
               </div>
               
               <div class="dodajProizvod">
                  
                   <h1>Podaci korisnika</h1>
                   <?php
                    $db = @mysqli_connect('localhost','root','','newproject');
                    mysqli_query($db,"SET NAMES UTF8");
                    $idKorisnika = $_SESSION['id'];
                    $upit = "SELECT * FROM korisnici WHERE id='{$idKorisnika}'";
                    $rezultat = mysqli_query($db, $upit);
                    $red = mysqli_fetch_object($rezultat);
                   ?>
                   <form id="formaDodajProizvod">
                        
                        <label for="imeKorisnika">Ime korisnika:</label>
                        <input type="text" id="imeKorisnika" value="<?php echo $red->korisnik_ime ?>">
                        
                        <label for="prezimeKorisnika">Prezime korisnika:</label>
                        <input type="text" id="prezimeKorisnika" value="<?php echo $red->korisnik_prezime ?>"><br>
                        
                       <label for="emailKorisnika">E-mail: <i>(nije moguće menjati)</i></label>
                        <input type="text" id="emailKorisnika" value="<?php echo $red->korisnik_email ?>" readonly><br>
                        
                        <button id="dodatneSlikeBtn" style='padding:10px; cursor:pointer' onclick="return false">Želite da izmenite lozinku?</button><br><br>
                        
                        <div class="dodatneSlike" style="border:none">
                            <label for="novaLozinka">Unesite novu lozinku:</label>   
                            <input type="password" id='novaLozinka'> <br>
                            <label for="novaLozinka2">Ponovite novu lozinku:</label>   
                            <input type="password" id='novaLozinka2'>
                        </div> <br>
                        
                        <div class="odgovorIzmeniKorisnika" style='font-weight:600'></div><br><br>
                        
                        <input type="button" onclick="sacuvajIzmeneKorisnika(<?php echo $_SESSION['id'] ?>)" value="Sačuvaj izmene">
                   </form>
                   
               </div><!-- end of .dodajProizvod -->
 
            </div> <!-- end of .leftWrapper -->

           
           
           
            <!---------- Sidebar sadrzaj -------->
            <div class="sidebarWrapper">
            <?php include_once("_sidebar.php") ?>
                              
        </div><!-- end of .mainWrapper --> 
        
        
        
        
        <!------ back to top button ------>
        
        <p class="backToTop"><i class="fas fa-chevron-up"></i></p>

        
    </div><!-- end of .wrapper -->
    
    
    <!------------- Footer ------------>
    <?php include_once("_footer.php") ?>
        
</body>
</html>