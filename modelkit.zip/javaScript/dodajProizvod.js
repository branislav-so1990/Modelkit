$(document).ready(function(){
    //Animacija dodatnih slika
    $('#dodatneSlikeBtn').click(function(){
        $('.dodatneSlike').slideToggle();
    })
    
    
    //Dodavanje novog proizvoda u bazu
    $('#dodajProizvod').click(function(){
        
        var naziv = $('#nazivProizvoda').val();
        var kategorija = $('#kategorijaProizvoda').val();
        var cena = $('#cenaProizvoda').val();
        var slikaGlavna = $('#slikaProizvoda').val(); 
        var dodatneSlike = $('#dodatneSlike').val();
        var opis = $('#opisProizvoda').val();
        
        $.ajax({
            url: "php/dodajProizvod.php",
            type: "POST",
            data: new FormData(document.getElementById("formaDodajProizvod")),
            contentType: false,
            cache: false,
            processData: false,
            success: uspeh,
            error: greska,
            beforeSend: preSlanja
        });
        
        function uspeh(response){
            $('.odgovorProizvod').html(response); 
        }
        
        function greska(xhr){
            $('.odgovorProizvod').html(xhr.status + " " + xhr.statusText); 
        }
        
        function preSlanja(){
            //brisanje poruke kada se krene kucati
            $('#nazivProizvoda, #cenaProizvoda, #opisProizvoda').keypress(function(){
                $('.odgovorProizvod').html("");
            });
            
            if(naziv=="") {
                $('.odgovorProizvod').html('<b>Niste uneli naziv !</b>');
                $('#nazivProizvoda').focus();
                return false;
            }
            if(kategorija==0) {
                $('.odgovorProizvod').html('<b>Niste izabrali kategoriju !</b>');
                $('#kategorijaProizvoda').focus();
                return false;
            }
            if(cena==""){
                $('.odgovorProizvod').html('<b>Niste uneli cenu !</b>');
                $('#cenaProizvoda').focus();
                return false;
            }
            if(slikaGlavna=="") {
                $('.odgovorProizvod').html('<b>Niste izabrali sliku !</b>');
                return false;
            }
        }
        
        
    });
}) 
