var myApp = angular
    .module('modulKorisnici',[])
    .controller('kontrolerKorisnici', function($scope, $http){
        
        //Prikaz svih korisnika
        $scope.prikaziSve = function(){
            
            $http.post('php/korisnici.php')
            .then (function(response){
                $scope.korisnici = response.data;
                console.log(response.data);
                $scope.ukupno = $scope.korisnici.length;
            })
        }
        
        
        //Izmena jednog korisnika - priprema
        $scope.izmeni = function(id){
            $('.izmena').slideDown();
            $http.post('php/korisnici.php?funkcija=izmena&id='+id)
            .then(function(response){
                $scope.odgovor = response.data;
                $scope.id = parseInt($scope.odgovor[0].id);
                $scope.ime = $scope.odgovor[0].korisnik_ime;
                $scope.prezime = $scope.odgovor[0].korisnik_prezime;
                $scope.email = $scope.odgovor[0].korisnik_email;
                $scope.status = $scope.odgovor[0].korisnik_status;
                $scope.prikaziSve();
            })
        }
        
        //Sacuvavanje nove izmene u bazu
        $scope.sacuvajIzmene = function(id){
            //alert('cuvanje'+id)
            $http.post('php/korisnici.php?funkcija=sacuvaj&id='+id,
            {id:$scope.id, ime:$scope.ime, prezime:$scope.prezime, email:$scope.email, status:$scope.status})
            .then(function(response){
                alert(response.data);
                $scope.prikaziSve();
                $('.izmena').slideUp();
            })
        }
        
        //Brisanje jednog korisnika
        $scope.obrisi = function(id){
            if(confirm("Da li ste sigurni?")){
                $http.post('php/korisnici.php?funkcija=brisanje&id='+id)
                .then (function(response){
                    //$scope.odgovor = response.data;
                    $scope.prikaziSve();  
                })
            } 
        }
        
        
        
        //Run
        $scope.prikaziSve();
         
    })