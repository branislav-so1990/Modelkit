function galerija(id){
    $.post('php/galerija.php?id='+id, function(response){
        
        var slika = "<img src='images/models/"+response+"'>";
        //console.log(slika);
        $("#galerijaGlavnaSlika").animate({opacity:"0"}, "slow", function(){
               $("#galerijaGlavnaSlika").attr("src", $(slika).attr("src")).animate({opacity:"1"}, "slow");
            })
    })
}
