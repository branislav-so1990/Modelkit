$(document).ready(function(){
    //RUN
    prikaziSadrzaj();
    prikaziKupljeno();
})

function dodaj_u_korpu(id){
    $.post('php/3korpaObrada.php?id='+id, function(response){
        $('#dodaj').html('Dodato u korpu !');
        $('#dodaj').css({'background':'#398d39', 'outline':'none', 'color':'#fff'});
    })
}

function obrisiProizvod(id){
    if(!confirm('Da li želite da obrišete proizvod!?'))
        return false;
    else {
        $.post('php/3modeliObrada.php?id='+id, function(response){
            alert(response);
            location.assign ("index.php");
        })
    }
}

function sacuvajIzmene(id){
    $.ajax({
            url: 'php/3modeliObrada.php?id='+id+'&izmeni',
            type: 'post',
            data: new FormData(document.getElementById('formaIzmeniProizvod')),
            contentType: false,
            cache: false,
            processData: false,
            success: uspeh,
            error: greska,
            beforeSend: preSlanja
        });
        var naziv = $('#nazivIzmena').val();
        var kategorija = $('#kategorijaIzmena').val();
        var cena = $('#cenaIzmena').val();
        var opis = $('#opisIzmena').val();
    
        function uspeh(response){
            $('.odgovorIzmena').html(response);
            location.assign ('model_detalji.php?id='+id)
        }
        function greska(xhr){
            $('.odgovorIzmena').html(xhr.status+" "+xhr.statusText);
        }
        function preSlanja(){
            if(!confirm('Da li ste sigurni?')){
                return false;
            }
        }
}

//--- Prikazivanje sadrzaja KORPE na stranici ---

function prikaziSadrzaj(){
    $.post('php/3korpaObrada.php?funkcija=sadrzaj', function(response){
        $('#sadrzajKorpe').html(response);
    })
}

function prikaziKupljeno(){
    $.post('php/3korpaObrada.php?funkcija=kupljeno', function(response){
        $('#kupljenoKorpa').html(response);
    })
}

function ukloniIzKorpe(id){
    $.post('php/3korpaObrada.php?funkcija=ukloni', {idKupovine:id}, function(response){
        prikaziSadrzaj();
    })
}

function kupi(idKupovine){
    //Prikazivanje forme za podatke
    $('.formaZaKupovinu').slideDown();
    $('.idKupovine').val(idKupovine);
}

function otkazi(){
    $('.formaZaKupovinu').slideUp();
}

function potvrdiKupovinu() {
    var id = $('.idKupovine').val();
    var ime = $('.imeKupca').val();
    var adresa = $('#adresa').val();
    var telefon = $('#telefon').val();
    
    if(ime==""){
        $('.odg').html('Morate uneti ime!');
        return false;
    }
    if(adresa==""){
        $('.odg').html('Morate uneti adresu!');
        return false;
    }
    if(telefon==""){
        $('.odg').html('Morate uneti telefon!');
        return false;
    }
    
    $.post('php/3korpaObrada.php?funkcija=kupi', {idKupovine:id, ime:ime, adresa:adresa, telefon:telefon}, function(response){
        $('.odg').html(response);
        prikaziSadrzaj();
        prikaziKupljeno();
    })
}







