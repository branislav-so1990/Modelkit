

// Komentari na proizvodima
function prikaziKomentare(){
    $.get('php/komentari.php?prikazi', function(response){
        //console.log(response)
    })
}

function obrisiKomentar(id){
    if(!confirm('Da li sigurno želite da obrišete komentar?!'))
        return false;
    else {
        $.get('php/komentari?id='+id, function(response){
            alert(response);
            location.reload();
        })
    }
}

function dodajKomentar(id){
    
    var sadrzaj = $('#sadrzajKomentar').val();
    $('#sadrzajKomentar').keypress(function(){
        $('#sadrzajKomentar').css({'border':'1px solid #ccc'});
        $('.odg').html("");
    })
    
    
    if(sadrzaj==""){
        $('.odg').html('<b>Niste popunili sadržaj!</b>');
        $('#sadrzajKomentar').css({'border':'1px solid red'});
        $('#sadrzajKomentar').focus();
        return false;
    }
    else {
        $.post('php/komentari?id='+id, {sadrzaj:sadrzaj}, function(response){
            $('.odg').html(response);
            location.reload();
        })
    }
    
}


