var myApp = angular 
    .module ('myModule',[])
    .controller ('myController', function($scope, $http){
        
        //--- Prikaz svih modela iz baze ---
        $scope.prikaziModele = function() {
            $http.get('php/3modeliObrada.php')
            .then (function(response){
                $scope.modeli = response.data;
                $scope.ukupno = $scope.modeli.length;
                $scope.brStrana = $scope.modeli.length;
            })
        }
        
        //--- Prikaz detalja jednog modela ---
        $scope.prikaziModel = function(id){
            location.assign ('model_detalji.php?id='+id)
        }
        
        //--- Izmena JEDNOG modela ---
        $scope.izmeniProizvod = function(id){
             // Animacija 
            $('.jedanModelDetalji, .komentariWrapper').slideToggle();
            $('.dodajProizvod').css({'display':'block'});
            $('#backBtn1').css({'display':'none'});
            // Vracanje
            $('#backBtn2').click(function(){
                $('.jedanModelDetalji, .komentariWrapper').slideToggle();
                $('.dodajProizvod').css({'display':'none'});
                $('#backBtn1').css({'display':'block'});
            })
            
             $http.get ('php/3modeliObrada.php?id='+id)
                .then (function(response){     
                    $scope.odgovor = response.data;
                    //console.log($scope.odgovor); //mora ici .odgovor[0]
                    $scope.id = parseInt($scope.odgovor[0].id);
                    $scope.naziv = $scope.odgovor[0].model_naziv;
                    $scope.kategorija = $scope.odgovor[0].model_kategorija;
                    $scope.cena = parseInt($scope.odgovor[0].model_cena);
                    $scope.dostupan = $scope.odgovor[0].model_dostupan;
                    $scope.opis = $scope.odgovor[0].model_opis;    
                });
        }
        
        
        //RUN
        $scope.prikaziModele();
    })
