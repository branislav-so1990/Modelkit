$(document).ready(function(){
    
})

function sacuvajIzmeneKorisnika(idKorisnika){
    var ime = $('#imeKorisnika').val();
    var prezime = $('#prezimeKorisnika').val();
    var email = $('#emailKorisnika').val();
    var novaLozinka = $('#novaLozinka').val();
    var novaLozinka2 = $('#novaLozinka2').val();
    
    if(ime == ""){
        $('.odgovorIzmeniKorisnika').html('Niste uneli ime!');
        return false;
    }
    if(prezime == ""){
        $('.odgovorIzmeniKorisnika').html('Niste uneli prezime!');
        return false;
    }
    if(!confirm('Da li ste sigurni?'))
        return false;
    
    //ako nije menjana lozinka
    if(novaLozinka == "" || novaLozinka2 == ""){
        $.post('php/podaciKorisnika.php',{id:idKorisnika, ime:ime, prezime:prezime}, function(response){
            $('.odgovorIzmeniKorisnika').html(response);
        })
    }
    else if(novaLozinka !== novaLozinka2){
        $('.odgovorIzmeniKorisnika').html('Lozinke nisu iste!'); 
    } // ako jeste menjana lozinka
    else {
        $.post('php/podaciKorisnika.php',{id:idKorisnika, ime:ime, prezime:prezime, novaLozinka:novaLozinka, novaLozinka2:novaLozinka2}, function(response){
            $('.odgovorIzmeniKorisnika').html(response);
        })
    }
    
}
