// Kontaktirajte nas
function kontakt(){
    var ime = $('#kontaktIme').val();
    var email = $('#kontaktEmail').val();
    var sadrzaj = $('#kontaktSadrzaj').val();
    
    $('#kontaktIme, #kontaktEmail, #kontaktSadrzaj').keypress(function(){
        $('.kontaktOdg').html('');
    })
    
    if(ime==""){
        $('.kontaktOdg').html('Niste uneli ime!');
        $('#kontaktIme').focus();
        return false;
    }
    if(email==""){
        $('.kontaktOdg').html('Niste uneli e-mail!');
        $('#kontaktEmail').focus();
        return false;
    }
    if(sadrzaj==""){
        $('.kontaktOdg').html('Niste uneli sadrzaj!');
        $('#kontaktSadrzaj').focus();
        return false;
    }
    $.post('php/kontakt.php', {ime:ime, email:email, sadrzaj:sadrzaj}, function(response){
        $('.kontaktOdg').html(response);
    })
}