$(document).ready(function(){
    
    //loading animacija
    /*$(window).on("load", function(){
        $('.loader').css({"display":"block"});
        $(".loader").fadeOut("slow");
    })
    */
    
    //scrol to...
    $("#makete").click(function() {
            $('html, body').animate({
                scrollTop: parseInt($(".filteri").offset().top)
            }, 1000);
        });
    
    $("#contactUs").click(function() {
            $('html, body').animate({
                scrollTop: parseInt($(".footer").offset().top)
            }, 1000);
        });
    
    $("#login").click(function() {
            $('html, body').animate({
                scrollTop: parseInt($(".prijava").offset().top)
            }, 1500);
        });
    
    
    
    
    //back to top button
    $(".backToTop").click(function() {
            $('html, body').animate({
                scrollTop: parseInt($("header").offset().top)
            }, 1500);
        });

    
    
    //---- Animacija Prijave/Registracije -----------------------
    
    // okretanje forme 180 stepeni
    $('#registerHere').click(function(){
        $('.prijava').css({'transform':'rotateY(-180deg)'});
        $('.registracija').css({'transform':'rotateY(0deg)'});
    });
    
    // vracanje forme za 180 stepeni
    $('#loginHere').click(function(){
        $('.registracija').css({'transform':'rotateY(-180deg)'});
        $('.prijava').css({'transform':'rotateY(0deg)'});
    });
    
    
    //---- Prikazivanje forme za komentar ---------
    $('.showComment').click(function(){
        $('.odgovorUsera').slideToggle();
        $('#sadrzajKomentar').focus();
    });
    
    
    //---- Animacija wrappera sidebar-a -----------------------
    //spustanje wrappera
    $('#registerHere').click(function(){
        $('.container').css({'height':'870px'});
        $('.container').css({'transition':'0.3s'});
    });
    
    //vracanje gore
    $('#loginHere').click(function(){
       $('.container').css({'height':'400px'});
       $('.container').css({'transition':'1s ease-out', 'transition-delay':'0.6s'});
    });
    
    
    
    
    
    
    
})

