$(document).ready(function () {

    //--- Logovanje postojeceg korisnika - Ajax ---
    $('#loginBtn').click(function () {
        var ime = $('#username').val();
        var lozinka = $('#password').val();

        $.ajax({
            url: "php/prijava.php",
            type: "POST",
            data: {
                Logime: ime,
                Loglozinka: lozinka
            },
            success: uspeh,
            error: greska,
            beforeSend: preSlanja
        });

        function uspeh(response) {
            if (response.indexOf(".php") == -1)
                $('.odgovorLog').html(response);
            else
                location.assign("index.php");
        }

        function greska(xhr) {
            $('.odgovorLog').html(xhr.status + " " + xhr.statusText);
        }

        function preSlanja() {
            //brisanje poruke kada se krene kucati
            $('#username, #password').keypress(function () {
                $('.odgovorLog').html("");
                $('#username, #password').css({
                    'border': '1px solid black'
                });
            });


            if (ime == "") {
                $('.odgovorLog').html("Niste uneli ime!");
                $('#username').focus();
                $('#username').css({
                    'border': '2px solid red'
                });
                return false;
            }
            if (lozinka == "") {
                $('.odgovorLog').html("Niste uneli lozinku!");
                $('#password').focus();
                $('#password').css({
                    'border': '2px solid red'
                });
                return false;
            }

        } // end of preSlanja

    });


    //--- Registracija novog korisnika - Ajax ---
    $('#registerBtn').click(function () {

        var ime = $('#firstName').val();
        var prezime = $('#lastName').val();
        var lozinka = $('#Rpassword').val();
        var ponovljenalozinka = $('#RRpassword').val();
        var email = $('#email').val();

        $.ajax({
            url: "php/prijava.php",
            type: "POST",
            data: {
                ime: ime,
                prezime: prezime,
                lozinka: lozinka,
                ponovljenalozinka: ponovljenalozinka,
                email: email
            },
            success: uspeh,
            error: greska,
            beforeSend: preSlanja
        });

        function uspeh(response) {
            $('.odgovorReg').html(response);
        }

        function greska(xhr) {
            $('.odgovorReg').html(xhr.status + " " + xhr.statusText);
        }

        function preSlanja() {

            //brisanje poruke kada se krene kucati
            $('#firstName, #lastName, #Rpassword, #email, #RRpassword').keypress(function () {
                $('.odgovorReg').html("");
                $('#firstName, #lastName, #Rpassword, #email, #RRpassword').css({
                    'border': '1px solid black'
                });
            });
            //provera 
            if (ime == "") {
                $('.odgovorReg').html('Niste uneli ime !');
                $('#firstName').focus();
                $('#firstName').css({
                    'border': '2px solid red'
                });
                return false;
            }
            if (ime.indexOf("'") !== -1) {
                $('.odgovorReg').html('imate znak "');
                $('#firstName').focus();
                $('#firstName').css({
                    'border': '2px solid red'
                });
                return false;
            }
            if (prezime == "") {
                $('.odgovorReg').html('Niste uneli prezime!');
                $('#lastName').focus();
                $('#lastName').css({
                    'border': '2px solid red'
                });
                return false;
            }
            if (lozinka == "") {
                $('.odgovorReg').html('Niste uneli lozinku !');
                $('#Rpassword').focus();
                $('#Rpassword').css({
                    'border': '2px solid red'
                });
                return false;
            }
            if (lozinka.length < 5) {
                $('.odgovorReg').html('Minimum 5 slova !');
                $('#Rpassword').focus();
                $('#Rpassword').css({
                    'border': '2px solid red'
                });
                return false;
            }
            if (ponovljenalozinka == "") {
                $('.odgovorReg').html('Morate potvrditi lozinku !');
                $('#RRpassword').focus();
                $('#RRpassword').css({
                    'border': '2px solid red'
                });
                return false;
            }
            if (lozinka !== ponovljenalozinka) {
                $('.odgovorReg').html('Lozinke se ne poklapaju !');
                $('#Rpassword').focus();
                $('#Rpassword, #RRpassword').css({
                    'border': '2px solid red'
                });
                return false;
            }
            if (email == "") {
                $('.odgovorReg').html('Niste uneli e-mail !');
                $('#email').focus();
                $('#email').css({'border':'2px solid red'});
                return false;
            }
        }
    });







});