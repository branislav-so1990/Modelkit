<?php
include_once('php/classLog.php');
$db = @mysqli_connect('localhost','root','','newproject');

if(mysqli_connect_error()){
    echo "Greska prilikom konekcije na bazu!<br>".mysqli_connect_error();
    exit();
}
mysqli_query($db, "SET NAMES UFT8");

//session_start();
if(isset($_GET['odjava'])){
    Log::upisiAdmin("logovanje.txt", "Uspesna odjava korisnika: ".$_SESSION['user']." | status: ".$_SESSION['status']);
    unset($_SESSION['user']);
    unset($_SESSION['status']);
    unset($_SESSION['id']);
    session_destroy();
    header("location: index.php");
}
//Provera da li postoji nesto u korpi
if(isset($_SESSION['id'])){
    $idKupca = $_SESSION['id'];
    $upit = "SELECT * FROM korpa WHERE id_kupca='{$idKupca}' AND kupljen=0";
    $rezultat = mysqli_query($db, $upit);
    if(mysqli_num_rows($rezultat)==0)
        $korpa=0;
    else
        $korpa=mysqli_num_rows($rezultat);
}

?>




<header>
    <div class="logo">
        <img src="images/web/modelkit_logo.png" alt="logo">
    </div>
    <nav>
        <ul>
            <li><a href="index.php">Početna</a></li>
            <?php
            if(!isset($_GET['id'])){
                echo "<li><a href='#' id='makete'>Makete</a></li>";
            }?>
            <li><a href="#" id="contactUs">Kontakt</a></li>
            <?php
                if(isset($_SESSION['user'])){
                    echo "<li><a href='#' id='login' title='Pogledaj profil'>".$_SESSION['user']."</a></li>";
                    echo "<li><a href='korpa.php'><img src='images/web/korpa.png' alt='korpa'> <span class='korpaBroj'>".$korpa."</span></a></li>";
                }
                else
                    echo "<li><a href='#' id='login'>Prijavi se</a></li>"
            ?>
        </ul>
        <img src="images/web/hamburger_menu.png" alt="menu">
    </nav>
</header>