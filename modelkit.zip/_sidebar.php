<?php
//Provera da li postoji nesto u korpi
if(isset($_SESSION['id'])){
    $idKupca = $_SESSION['id'];
    $upit = "SELECT * FROM korpa WHERE id_kupca='{$idKupca}' AND kupljen=0";
    $rezultat = mysqli_query($db, $upit);
    if(mysqli_num_rows($rezultat)==0)
        $korpa=0;
    else
        $korpa=mysqli_num_rows($rezultat);
}

?>



<!------------ Prijava i Registracija korisnika ----------->

<div class="userAccount">
    <div class="container">

        <!------ Prijava ------>

        <div class="prijava">
            <?php
                if(isset($_SESSION['user'])){
                    echo "<p>Nalog korisnika</p>";
                    echo "<ul>
                            <li><img src='images/web/user.png' width='25px'><a href='podaciKorisnika.php' class='admin'>Podaci</a></li>
                            <li><img src='images/web/korpa.png' width='25px'><a href='korpa.php' class='admin'>Korpa</a></li>
                            <li><img src='images/web/exit.png' width='25px'><a href='index.php?odjava' class='admin'>Odjavi se</a></li>
                          </ul>";
                    
                    if(isset($_SESSION['status']) AND $_SESSION['status'] == "admin"){
                        echo "<h3>Administrator:</h3>";
                        echo "<ul>
                                <li><img src='images/web/proizvod.png' width='25px'><a href='dodajProizvod.php' class='admin'>Dodaj proizvod</a></li>
                                <li><img src='images/web/user.png' width='25px'><a href='korisnici.php' class='admin'>Korisnici</a></li>
                                <li><img src='images/web/logs.png' width='25px'><a href='admin/statistike.php' class='admin'>Statistike</a><br></li>
                              </ul>";
                    }
                }
                else {
                    echo "<p>Prijavi se</p>";
                    echo "<form id='formaLog'>
                    <label for='username'>Korisničko ime:</label>
                    <input type='text' id='username'>

                    <label for='password'>Lozinka:</label>
                    <input type='password' id='password'>

                    <div class='odgovor odgovorLog'></div>

                    <input type='button' id='loginBtn' value='Prijavi se'>

                    <i>Nemaš nalog? <a id='registerHere'>Registruj se ovde!</a></i>
                    </form>";
                }
                ?>


        </div><!-- end of .prijava -->

        <!------ Registracija ------>

        <div class="registracija">
            <p>Registruj se</p>
            <form id="forma" name="forma">
                <img src="images/web/no_user2.png" alt="avatar">

                <label for="firstName">Ime:</label>
                <input type="text" id="firstName">

                <label for="lastName">Prezime:</label>
                <input type="text" id="lastName">

                <label for="Rpassword">Lozinka:</label>
                <input type="password" id="Rpassword">

                <label for="RRpassword">Ponovi lozinku:</label>
                <input type="password" id="RRpassword">

                <label for="email">E-mail:</label>
                <input type="email" name="email" id="email">


                <div class="odgovor odgovorReg"></div>

                <input type="button" id="registerBtn" value="Registruj se">

                <i>Imaš nalog? <a id="loginHere">Prijavi se ovde!</a></i>
            </form>
        </div><!-- end of .registracija -->
    </div><!-- end of .container -->
</div><!-- end of .userAccount -->


<!---------- Društvene mreže -------->

<div class="socialMedia">
    <p class="naslov">Društvene mreže</p>
    <div class="boxes">
        <a href="https://www.facebook.com/" target="_blank" title="Facebook"><i class="fab fa-facebook-f"></i></a>
        <a href="https://twitter.com/" target="_blank" title="Twitter"><i class="fab fa-twitter"></i></a>
        <a href="https://www.instagram.com/" target="_blank" title="Instagram"><i class="fab fa-instagram"></i></a>
        <a href="https://www.pinterest.com/" target="_blank" title="Pinterest"><i class="fab fa-pinterest"></i></a>
    </div>
</div><!-- end of .socialMedia -->


</div><!-- end of .sidebarWrapper -->