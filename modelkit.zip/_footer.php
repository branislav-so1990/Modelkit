<footer class="footer">
    <div class="wrapper footerWrapper">
        <div class="left">
            <p>Gde se nalazimo?</p>
            <div id='mojamapa'></div>
        </div>
        <div class="right">
            <p>Kontaktirajte nas:</p>
            <input type="text" id='kontaktIme' placeholder="Vaše ime"><br>
            <input type="text" id='kontaktEmail' placeholder="E-mail"><br>
            <textarea name="" id="kontaktSadrzaj" cols="54" rows="5" placeholder="Unesite sadržaj"></textarea><br>
            <div class="kontaktOdg"></div>
            <input type="button" id="kontaktBtn" onclick='kontakt()' value="Pošalji">
        </div>
    </div>
    <p class='copyright'>Sva prava zadržana | Modelkit © 2019, Beograd Srbija</p>

    <!-- Leaflet mape -->
    <script src="https://unpkg.com/leaflet@1.5.1/dist/leaflet.js" integrity="sha512-GffPMF3RvMeYyc1LWMHtK8EbPv0iNZ8/oTtHPx9/cc2ILxQ+u905qIwdpULaqDkyBKgOaB57QTMg7ztg8Jm2Og==" crossorigin=""></script>
    <script>
        var mymap = L.map('mojamapa').setView([44.848428, 20.404615], 13);
        var marker = L.marker([44.848428, 20.404615]).addTo(mymap);
        marker.bindPopup("<img src='images/web/modelkit_logo.png' style='height:20px;'>").openPopup();

        L.tileLayer('https://a.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            attribution: '© OpenStreetMap contributors',
            maxZoom: 18,
        }).addTo(mymap);
    </script>
</footer>